package com.jobapplication.Job.Application.entity;

public enum AccountType {
    APPLICANT,
    EMPLOYER
}
