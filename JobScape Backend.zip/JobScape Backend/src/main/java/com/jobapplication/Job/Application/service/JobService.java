package com.jobapplication.Job.Application.service;

import com.jobapplication.Job.Application.dto.ApplicantDto;
import com.jobapplication.Job.Application.dto.Application;
import com.jobapplication.Job.Application.dto.JobDto;

import java.util.List;

public interface JobService {

    public JobDto postJob(JobDto jobDto);

    public JobDto closeJob(Long id) throws Exception;
    public JobDto reopenJob(Long id) throws Exception;


    public List<JobDto> getAllJobs();

    public JobDto getJob(Long id) throws Exception;

    public String applyJob(Long id, ApplicantDto applicantDto) throws Exception;

    public List<JobDto> getPostedJob(Long id);

   public String changeAppStatus(Application application) throws Exception;
}
