package com.jobapplication.Job.Application.jwt;

import com.jobapplication.Job.Application.dto.UserDto;
import com.jobapplication.Job.Application.service.UserService;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.MalformedJwtException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;

@Service
public class MyUserDetailsService implements UserDetailsService {
    @Autowired
    private UserService userService;
    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
       try{
           UserDto user = userService.getUserByEmail(email);
           return new CustomUserDetails(
                   user.getId(),
                   email,
                   user.getPassword(),    // Password comes first
                   user.getName(),
                   user.getProfileId(),// Then name
                   user.getAccountType(),
                   new ArrayList<>()
           );
       }
       catch (IllegalArgumentException e)
       {
           e.printStackTrace();
       }
       catch (ExpiredJwtException e)
       {
           e.printStackTrace();
       }
       catch (MalformedJwtException e)
       {
           e.printStackTrace();
       }
       catch (Exception e) {
           e.printStackTrace();
       }

       return null;
    }
}
