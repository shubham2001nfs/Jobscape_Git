package com.jobapplication.Job.Application.service;

import com.jobapplication.Job.Application.dto.NotificationDto;
import com.jobapplication.Job.Application.entity.Notification;

import java.util.List;

public interface NotificationService {

    public NotificationDto sendNotification(NotificationDto notificationDto);
    public List<NotificationDto> getUnreadNotifications(Long userId);

   public String readNotification(Long id) throws Exception;
}
