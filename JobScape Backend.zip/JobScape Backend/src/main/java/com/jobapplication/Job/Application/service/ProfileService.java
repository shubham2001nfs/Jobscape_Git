package com.jobapplication.Job.Application.service;

import com.jobapplication.Job.Application.dto.ProfileDto;
import com.jobapplication.Job.Application.exception.ProfileNotFoundException;

import java.util.List;

public interface ProfileService {

    public Long createProfile(String email,String name);

    public ProfileDto getProfile(Long id) throws ProfileNotFoundException;

    public ProfileDto updateProfile(ProfileDto profileDto) throws ProfileNotFoundException;

    public List<ProfileDto> getAll();
}
