package com.jobapplication.Job.Application.service;

import com.jobapplication.Job.Application.dto.ProfileDto;
import com.jobapplication.Job.Application.entity.Profile;
import com.jobapplication.Job.Application.entity.User;
import com.jobapplication.Job.Application.exception.ProfileNotFoundException;
import com.jobapplication.Job.Application.repository.ProfileRepository;
import com.jobapplication.Job.Application.repository.UserRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ProfileServiceImpl implements ProfileService {

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private ProfileRepository profileRepository;

    @Autowired
    private UserRepository userRepository;

    @Override
    public Long createProfile(String email,String name) {
        Profile profile = new Profile();
        profile.setEmail(email);
        profile.setName(name);
        profile.setSkills(new ArrayList<>());
        profile.setCertificates(new ArrayList<>());
        profile.setExperiences(new ArrayList<>());
        profileRepository.save(profile);
        return profile.getId();
    }

    @Override
    public ProfileDto getProfile(Long id) throws ProfileNotFoundException {
        Profile profile = profileRepository.findById(id)
                .orElseThrow(() -> new ProfileNotFoundException("Profile not found!"));

        // Simply use ModelMapper to map all fields including the picture string
        return modelMapper.map(profile, ProfileDto.class);
    }

    @Override
    public ProfileDto updateProfile(ProfileDto profileDto) throws ProfileNotFoundException {
        // Check if profile exists
        Profile profile = profileRepository.findById(profileDto.getId())
                .orElseThrow(() -> new ProfileNotFoundException("Profile not found!"));

        // Explicitly update fields (don't rely on ModelMapper alone)
        profile.setJobTitle(profileDto.getJobTitle());
        profile.setCompany(profileDto.getCompany());
        profile.setPicture(profileDto.getPicture());
        profile.setTotalExp(profileDto.getTotalExp());
        profile.setLocation(profileDto.getLocation());
        profile.setAbout(profileDto.getAbout());
        profile.setSkills(profileDto.getSkills());
        profile.setExperiences(profileDto.getExperiences());
        profile.setCertificates(profileDto.getCertificates());
        profile.setSavedJobs(profileDto.getSavedJobs());

        Profile updatedProfile = profileRepository.save(profile);
        return modelMapper.map(updatedProfile, ProfileDto.class);
    }

    @Override
    public List<ProfileDto> getAll() {
        List<Profile> profiles= profileRepository.findAll();
        return profiles.stream().map((x)-> modelMapper.map(x,ProfileDto.class)).collect(Collectors.toList());
    }
}