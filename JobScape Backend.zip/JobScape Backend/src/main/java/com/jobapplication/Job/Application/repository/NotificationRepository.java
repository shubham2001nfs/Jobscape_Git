package com.jobapplication.Job.Application.repository;

import com.jobapplication.Job.Application.entity.Notification;
import com.jobapplication.Job.Application.entity.NotificationStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface NotificationRepository extends JpaRepository<Notification,Long> {
public List<Notification> findByIdAndStatus(Long id , NotificationStatus status);
}
