package com.jobapplication.Job.Application.entity;

import com.jobapplication.Job.Application.dto.ApplicantDto;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "jobs")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Job
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String jobTitle;
    private String company;
    @ElementCollection
    private List<Applicant> applicants;
    private String about;
    private String experience;
    private String jobType;
    private String location;
    private Long packageOffered;
    private LocalDateTime postTime;
    private String description;
    @ElementCollection
    @CollectionTable(name = "job_skills_require",joinColumns = @JoinColumn(name = "job_id"))
    private List<String> skillsRequired;
    @Enumerated(EnumType.STRING)
    private JobStatus jobStatus;
    private Long postedBy;
}
