package com.jobapplication.Job.Application.controller;

import com.jobapplication.Job.Application.dto.NotificationDto;
import com.jobapplication.Job.Application.service.NotificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/notifications")
public class NotificationController {

    @Autowired
    private NotificationService notificationService;

    @GetMapping("/getAll/{userId}")
    public ResponseEntity<List<NotificationDto>> getAllNotifications(@PathVariable Long userId) {
        return new ResponseEntity<>(notificationService.getUnreadNotifications(userId), HttpStatus.OK);
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<String> readNotification(@PathVariable Long id) throws Exception {
        return new ResponseEntity<>(notificationService.readNotification(id), HttpStatus.OK);
    }

    @PostMapping("/send")
    public ResponseEntity<NotificationDto> sendNotification(@RequestBody NotificationDto notificationDto) {
        NotificationDto result = notificationService.sendNotification(notificationDto);
        return new ResponseEntity<>(result, HttpStatus.CREATED);
    }
}
