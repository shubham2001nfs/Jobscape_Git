package com.jobapplication.Job.Application.dto;

import com.jobapplication.Job.Application.entity.Certificate;
import com.jobapplication.Job.Application.entity.Experience;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ProfileDto {

    private Long id;
    private String name;
    private String email;
    private String jobTitle;
    private String company;

    private String picture;
    private Long totalExp;

    private String location;
    private String about;
    private List<String> skills;
    private List<Experience> experiences;
    private List<Certificate> certificates;
    private List<Long> savedJobs;

}
