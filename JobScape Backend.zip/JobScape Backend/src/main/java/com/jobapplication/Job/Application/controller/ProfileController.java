package com.jobapplication.Job.Application.controller;

import com.jobapplication.Job.Application.dto.ProfileDto;
import com.jobapplication.Job.Application.exception.ProfileNotFoundException;
import com.jobapplication.Job.Application.service.ProfileService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

@RestController
@CrossOrigin
@Validated
@RequestMapping("/profiles")
public class ProfileController {

    @Autowired
    private ProfileService profileService;

    @GetMapping("/getProfile/{id}")
    public ResponseEntity<ProfileDto> getProfile(@PathVariable Long id) throws ProfileNotFoundException {
        return new ResponseEntity<>(profileService.getProfile(id), HttpStatus.OK);
    }

    @PutMapping("/updateProfile")
    public ResponseEntity<ProfileDto> updateProfile(@RequestBody ProfileDto profileDto) throws Exception {
        return new ResponseEntity<>(profileService.updateProfile(profileDto),HttpStatus.OK);
    }

    @GetMapping("/getAll")
    public ResponseEntity<List<ProfileDto>> getAllProfiles()
    {
        return new ResponseEntity<List<ProfileDto>>(profileService.getAll(),HttpStatus.OK);
    }


}
