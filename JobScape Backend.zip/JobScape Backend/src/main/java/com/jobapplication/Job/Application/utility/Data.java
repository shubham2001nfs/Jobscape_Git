package com.jobapplication.Job.Application.utility;

public class Data {

    public static String getMessageBody(String otp,String name)
    {
        return "<!DOCTYPE html>\n" +
                "<html lang=\"en\">\n" +
                "<head>\n" +
                "  <meta charset=\"UTF-8\" />\n" +
                "  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\"/>\n" +
                "  <title>OTP Verification</title>\n" +
                "  <style>\n" +
                "    body {\n" +
                "      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;\n" +
                "      background-color: #f6f8fa;\n" +
                "      margin: 0;\n" +
                "      padding: 0;\n" +
                "    }\n" +
                "\n" +
                "    .container {\n" +
                "      max-width: 600px;\n" +
                "      margin: 50px auto;\n" +
                "      background-color: #ffffff;\n" +
                "      border: 1px solid #e2e8f0;\n" +
                "      border-radius: 8px;\n" +
                "      padding: 30px;\n" +
                "      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);\n" +
                "    }\n" +
                "\n" +
                "    .header {\n" +
                "      text-align: center;\n" +
                "      color: #FFA500;\n" +
                "      font-size: 24px;\n" +
                "      font-weight: bold;\n" +
                "      margin-bottom: 20px;\n" +
                "    }\n" +
                "\n" +
                "    .message {\n" +
                "      font-size: 16px;\n" +
                "      color: #2d3748;\n" +
                "      margin-bottom: 20px;\n" +
                "    }\n" +
                "\n" +
                "    .otp-box {\n" +
                "      text-align: center;\n" +
                "      background-color: #edf2f7;\n" +
                "      color: #1a202c;\n" +
                "      font-size: 28px;\n" +
                "      letter-spacing: 4px;\n" +
                "      padding: 15px;\n" +
                "      border-radius: 8px;\n" +
                "      font-weight: bold;\n" +
                "      margin: 20px 0;\n" +
                "    }\n" +
                "\n" +
                "    .footer {\n" +
                "      font-size: 14px;\n" +
                "      color: #718096;\n" +
                "      text-align: center;\n" +
                "      margin-top: 30px;\n" +
                "    }\n" +
                "  </style>\n" +
                "</head>\n" +
                "<body>\n" +
                "  <div class=\"container\">\n" +
                "    <div class=\"header\">Verification Code</div>\n" +
                "    <div class=\"message\">\n" +
                "      Hi " +name+ ",<br/><br/>\n" +
                "      Use the following One-Time Password (OTP) to complete your verification process. This code is valid for the next 5 minutes.\n" +
                "    </div>\n" +
                "    <div class=\"otp-box\">\n" +
               otp +
                "    </div>\n" +
                "    <div class=\"message\">\n" +
                "      If you did not request this, please ignore this email or contact support immediately.\n" +
                "    </div>\n" +
                "    <div class=\"footer\">\n" +
                "      Thank you,<br/>\n" +
                "      The JobScape Team\n" +
                "    </div>\n" +
                "  </div>\n" +
                "</body>\n" +
                "</html>\n";
    }
}
