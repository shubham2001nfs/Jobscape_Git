package com.jobapplication.Job.Application.entity;

public enum JobStatus {
    OPEN,CLOSED,DRAFT
}
