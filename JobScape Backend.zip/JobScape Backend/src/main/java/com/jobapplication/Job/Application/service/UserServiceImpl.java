package com.jobapplication.Job.Application.service;

import com.jobapplication.Job.Application.controller.Response;
import com.jobapplication.Job.Application.dto.LoginDto;
import com.jobapplication.Job.Application.dto.NotificationDto;
import com.jobapplication.Job.Application.dto.UserDto;
import com.jobapplication.Job.Application.entity.Otp;
import com.jobapplication.Job.Application.entity.User;

import com.jobapplication.Job.Application.exception.InvalidCredentialsException;
import com.jobapplication.Job.Application.exception.UserFoundException;
import com.jobapplication.Job.Application.repository.OtpRepository;
import com.jobapplication.Job.Application.repository.UserRepository;
import com.jobapplication.Job.Application.utility.Data;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.util.Optional;

@Service
public class UserServiceImpl implements UserService{

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private JavaMailSender javaMailSender;

    @Autowired
    private OtpRepository otpRepository;

    @Autowired
    private RedisOtpService redisOtpService;

    @Autowired
    private ProfileService profileService;

    @Autowired
    private NotificationService notificationService;

    @Override
    public UserDto getUserByEmail(String email) throws Exception {
                User user = userRepository.findByEmail(email).orElseThrow(()-> new Exception("User not found!"));
                return modelMapper.map(user,UserDto.class);
    }

    @Override
    public UserDto registerUser(UserDto userDto) throws UserFoundException {
        Optional<User> existsUser = userRepository.findByEmail(userDto.getEmail());
        if(existsUser.isPresent())
        {
            throw new UserFoundException("Email already registered!");
        }
        User createUser = new User();
        createUser.setProfileId(profileService.createProfile(userDto.getEmail(), userDto.getName()));
        createUser.setAccountType(userDto.getAccountType());
        createUser.setEmail(userDto.getEmail());
        createUser.setPassword(passwordEncoder.encode(userDto.getPassword()));
        createUser.setName(userDto.getName());
        User savedUser = userRepository.save(createUser);
        return modelMapper.map(savedUser,UserDto.class);

    }

    @Override
    public UserDto loginUser(LoginDto loginDto) throws InvalidCredentialsException {
        User user = userRepository.findByEmail(loginDto.getEmail()).orElseThrow(()-> new UsernameNotFoundException("User not found!"));
        if(!passwordEncoder.matches(loginDto.getPassword(), user.getPassword()))
        {
            throw new InvalidCredentialsException("Invalid Credentials!");
        }
        return modelMapper.map(user,UserDto.class);
    }

    @Override
    public Boolean sendOtp(String email) throws MessagingException {
       User user = userRepository.findByEmail(email).orElseThrow(()-> new UsernameNotFoundException("User not found!"));
        MimeMessage mimeMailMessage = javaMailSender.createMimeMessage();
        MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMailMessage,true);
        mimeMessageHelper.setTo(email);
        mimeMessageHelper.setSubject("Verification Code");
        String otp = generateOtp();
       redisOtpService.saveOtp(email,otp);
        mimeMessageHelper.setText(Data.getMessageBody(otp,user.getName()),true);
        javaMailSender.send(mimeMailMessage);
        return true;

    }

    @Override
    public Boolean verifyOtp(String email, String otp) {
        String storedOtp = redisOtpService.getOtp(email);
        return otp.equals(storedOtp);
    }

    @Override
    public Response resetPassword(LoginDto loginDto) {
        User user = userRepository.findByEmail(loginDto.getEmail()).orElseThrow(()-> new UsernameNotFoundException("User not found!"));
        user.setPassword(passwordEncoder.encode(loginDto.getPassword()));
        userRepository.save(user);
        NotificationDto not = new NotificationDto();
        not.setUserId(user.getId());
        not.setMessage("Password Changed Successfully");
        not.setAction("Reset Password");
        notificationService.sendNotification(not);
        return new Response("Password changed successfully..");
    }

    private static String generateOtp() {
        StringBuilder sb = new StringBuilder();
        SecureRandom secureRandom = new SecureRandom();
        for(int i=0;i<6;i++)
        {
            sb.append(secureRandom.nextInt(10));
        }

        return sb.toString();
    }
}
