package com.jobapplication.Job.Application.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import java.util.concurrent.TimeUnit;

@Service
public class RedisOtpService {

    @Autowired
    private StringRedisTemplate stringRedisTemplate;

    private static final long EXP=5;

    public void saveOtp(String email , String otp)
    {
        stringRedisTemplate.opsForValue().set(email,otp,EXP, TimeUnit.MINUTES);
    }

    public String getOtp(String email)
    {
        return stringRedisTemplate.opsForValue().get(email);
    }

    public void deleteOtp(String email)
    {
        stringRedisTemplate.delete(email);
    }
}
