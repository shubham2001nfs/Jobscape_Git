package com.jobapplication.Job.Application.entity;

public enum ApplicationStatus {
    APPLIED,INTERVIEWING,OFFERED,REJECTED
}
