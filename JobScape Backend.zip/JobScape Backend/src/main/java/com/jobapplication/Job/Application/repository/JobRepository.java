package com.jobapplication.Job.Application.repository;

import com.jobapplication.Job.Application.dto.JobDto;
import com.jobapplication.Job.Application.entity.Job;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface JobRepository extends JpaRepository<Job,Long> {

    public List<Job> findByPostedBy(Long id);
}
