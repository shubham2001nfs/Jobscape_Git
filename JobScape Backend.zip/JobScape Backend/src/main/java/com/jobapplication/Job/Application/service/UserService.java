package com.jobapplication.Job.Application.service;

import com.jobapplication.Job.Application.controller.Response;
import com.jobapplication.Job.Application.dto.LoginDto;
import com.jobapplication.Job.Application.dto.UserDto;
import com.jobapplication.Job.Application.exception.InvalidCredentialsException;
import com.jobapplication.Job.Application.exception.UserFoundException;
import jakarta.mail.MessagingException;


public interface UserService {

    public UserDto getUserByEmail(String email) throws Exception;

    public UserDto registerUser(UserDto userDto) throws UserFoundException;

    public UserDto loginUser(LoginDto loginDto) throws InvalidCredentialsException;

   public Boolean sendOtp(String email) throws MessagingException;

   public Boolean verifyOtp(String email, String otp);

    public Response resetPassword(LoginDto loginDto);
}
