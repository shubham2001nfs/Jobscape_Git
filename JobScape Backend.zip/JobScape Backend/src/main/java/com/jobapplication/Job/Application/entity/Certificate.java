package com.jobapplication.Job.Application.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.persistence.Embeddable;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.security.core.Transient;

import java.time.LocalDateTime;
import java.time.Year;
import java.time.YearMonth;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Embeddable
public class Certificate {
    private String name;
    private String issuer;
    private LocalDateTime issueDate;
    private String certificateId;
}
