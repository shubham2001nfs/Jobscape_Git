package com.jobapplication.Job.Application.exception;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.LocalDateTime;
import java.util.stream.Collectors;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorInfo> generalExceptionHandler(Exception exception)
    {
        ErrorInfo ex = ErrorInfo.builder().errorMessage(exception.getMessage()).errorCode(HttpStatus.INTERNAL_SERVER_ERROR.value()).timeStamp(LocalDateTime.now()).build();
        return new ResponseEntity<>(ex,HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler({MethodArgumentNotValidException.class, ConstraintViolationException.class})
    public ResponseEntity<ErrorInfo> validationExceptionHandler(Exception exception) {
        String message = "";
        if (exception instanceof MethodArgumentNotValidException methodArgumentNotValidException) {
            message = methodArgumentNotValidException.getAllErrors().stream().map(ObjectError::getDefaultMessage).collect(Collectors.joining(", "));
        } else {
            ConstraintViolationException cv = (ConstraintViolationException) exception;
            message = cv.getConstraintViolations().stream().map(ConstraintViolation::getMessage).collect(Collectors.joining(","));
        }

        ErrorInfo ex = ErrorInfo.builder().errorMessage(message).errorCode(HttpStatus.BAD_REQUEST.value()).timeStamp(LocalDateTime.now()).build();
        return new ResponseEntity<>(ex, HttpStatus.BAD_REQUEST);
    }
}
