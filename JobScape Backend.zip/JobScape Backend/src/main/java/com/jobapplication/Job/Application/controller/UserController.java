package com.jobapplication.Job.Application.controller;


import com.jobapplication.Job.Application.dto.LoginDto;
import com.jobapplication.Job.Application.dto.UserDto;
import com.jobapplication.Job.Application.exception.InvalidCredentialsException;
import com.jobapplication.Job.Application.exception.UserFoundException;
import com.jobapplication.Job.Application.service.UserService;
import jakarta.mail.MessagingException;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Pattern;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin
@Validated
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/register")
    public ResponseEntity<UserDto> createUser(@RequestBody @Valid UserDto userDto) throws UserFoundException {
        UserDto createdUser = userService.registerUser(userDto);
        return new ResponseEntity<>(createdUser, HttpStatus.CREATED);
    }

    @PostMapping("/login")
    public ResponseEntity<UserDto> createUser(@RequestBody @Valid LoginDto loginDto) throws UserFoundException, InvalidCredentialsException {
        UserDto loginUser = userService.loginUser(loginDto);
        return new ResponseEntity<>(loginUser, HttpStatus.OK);
    }

    @PostMapping("/sendOtp/{email}")
    public ResponseEntity<Response> sendOtp(@PathVariable @Email(message = "{user.email.invalid}") String email) throws MessagingException {
        Boolean send = userService.sendOtp(email);
        if(send == false)
        {
            return new ResponseEntity<>(new Response("Some error occured!"),HttpStatus.BAD_REQUEST);
        }
        return new ResponseEntity<>(new Response("OTP sent successfully.."),HttpStatus.OK);
    }

    @GetMapping("/verifyOtp/{email}/{otp}")
    public ResponseEntity<Response> verifyOtp(@PathVariable @Email(message = "{user.email.invalid}") String email, @PathVariable @Pattern(regexp = "^[0-9]{6}$",message = "{otp.invalid}") String otp)
    {
        Boolean verify = userService.verifyOtp(email,otp);
        if(verify == false)
        {
            return new ResponseEntity<>(new Response("OTP is invalid!"),HttpStatus.BAD_REQUEST);
        }
        return new ResponseEntity<>(new Response("OTP has been verified.."),HttpStatus.OK);
    }

    @PostMapping("/changePassword")
    public ResponseEntity<Response> changePassword(@RequestBody LoginDto loginDto)
    {
        return new ResponseEntity<>(userService.resetPassword(loginDto),HttpStatus.OK);
    }

}
