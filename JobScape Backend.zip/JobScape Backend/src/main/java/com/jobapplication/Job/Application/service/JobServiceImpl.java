package com.jobapplication.Job.Application.service;

import com.jobapplication.Job.Application.dto.ApplicantDto;
import com.jobapplication.Job.Application.dto.Application;
import com.jobapplication.Job.Application.dto.JobDto;
import com.jobapplication.Job.Application.dto.NotificationDto;
import com.jobapplication.Job.Application.entity.*;
import com.jobapplication.Job.Application.repository.JobRepository;
import jakarta.transaction.Transactional;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

@Service
public class JobServiceImpl implements JobService{

    @Autowired
    private JobRepository jobRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private NotificationService notificationService;

    @Override
    public JobDto postJob(JobDto jobDto) {
        jobDto.setPostTime(LocalDateTime.now());
        jobDto.setJobStatus(JobStatus.OPEN);

        Job mappedJob = modelMapper.map(jobDto, Job.class);
        Job postedJob = jobRepository.save(mappedJob);

        NotificationDto notification = new NotificationDto();
        notification.setUserId(jobDto.getPostedBy());
        notification.setMessage("Job Posted Successfully for " + jobDto.getJobTitle() + " at " + jobDto.getCompany());
        notification.setAction("Job Posted");
        notification.setRoute("/posted-job/" + postedJob.getId());

        notificationService.sendNotification(notification);


        return modelMapper.map(postedJob, JobDto.class);
    }


    @Override
    public JobDto closeJob(Long id) throws Exception {
        Job job = jobRepository.findById(id)
                .orElseThrow(() -> new Exception("Job not found!"));

        job.setJobStatus(JobStatus.CLOSED); // Update entity directly
        Job updatedJob = jobRepository.save(job);

        return modelMapper.map(updatedJob, JobDto.class); // Map for response
    }

    @Override
    public JobDto reopenJob(Long id) throws Exception {
        Job job = jobRepository.findById(id)
                .orElseThrow(() -> new Exception("Job not found!"));

        job.setJobStatus(JobStatus.OPEN);
        Job updatedJob = jobRepository.save(job);

        return modelMapper.map(updatedJob, JobDto.class);
    }


    @Override
    public List<JobDto> getAllJobs() {
        List<Job> jobs = jobRepository.findAll();
        return jobs.stream().map(job -> modelMapper.map(job,JobDto.class)).collect(Collectors.toList());
    }

    @Override
    public JobDto getJob(Long id) throws Exception {
        Job job = jobRepository.findById(id).orElseThrow(()-> new Exception("Job not found!"));
        return modelMapper.map(job,JobDto.class);
    }

    @Override
    @Transactional
    public String applyJob(Long id, ApplicantDto applicantDto) throws Exception {
        Job job = jobRepository.findById(id)
                .orElseThrow(() -> new Exception("Job not found!"));

        List<Applicant> applicants = job.getApplicants();
        if (applicants == null) {
            applicants = new ArrayList<>();
        }

        boolean alreadyApplied = applicants.stream()
                .anyMatch(x -> x.getApplicantId().equals(applicantDto.getApplicantId()));
        if (alreadyApplied) {
            throw new Exception("Already Applied");
        }

        // Set required fields
        applicantDto.setApplicationStatus(ApplicationStatus.APPLIED);
        applicantDto.setTimestamp(LocalDateTime.now());

        // Map and ensure all fields are set correctly
        Applicant applicant = modelMapper.map(applicantDto, Applicant.class);
        applicant.setApplicationStatus(applicantDto.getApplicationStatus()); // extra assurance
        applicant.setTimestamp(applicantDto.getTimestamp());

        applicants.add(applicant);
        job.setApplicants(applicants);
        jobRepository.save(job);

        return "Applied Successfully";
    }

    @Override
    public List<JobDto> getPostedJob(Long id) {
        List<Job> jobs = jobRepository.findByPostedBy(id);
        return jobs.stream().map(job -> modelMapper.map(job,JobDto.class)).collect(Collectors.toList());
    }

    @Override
    @Transactional
    public String changeAppStatus(Application application) throws Exception {
        Job job = jobRepository.findById(application.getId())
                .orElseThrow(() -> new Exception("Job not found!"));

        List<Applicant> applicants = job.getApplicants().stream().map((user)-> {
            if(application.getApplicantId() == user.getApplicantId())
            {
                user.setApplicationStatus(application.getApplicationStatus());
            }
            if(application.getApplicationStatus().equals(ApplicationStatus.INTERVIEWING))
            {
                user.setInterviewTime(application.getInterviewTime());
                NotificationDto noti = new NotificationDto();
                noti.setUserId(application.getApplicantId());
                noti.setMessage("Congratulations! You’ve been shortlisted for the next round.");
                noti.setAction("Interview Scheduled");
                noti.setRoute("/job-history");
                notificationService.sendNotification(noti);
            }

            return user;
        }).collect(Collectors.toList());

        job.setApplicants(applicants);
        jobRepository.save(job);
        return "Status Changed Successfully";
    }

}
