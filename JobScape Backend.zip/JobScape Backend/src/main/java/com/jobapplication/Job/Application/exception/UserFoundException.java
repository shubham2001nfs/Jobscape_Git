package com.jobapplication.Job.Application.exception;

public class UserFoundException extends Exception{

    public UserFoundException(String message)
    {
        super(message);
    }
}
