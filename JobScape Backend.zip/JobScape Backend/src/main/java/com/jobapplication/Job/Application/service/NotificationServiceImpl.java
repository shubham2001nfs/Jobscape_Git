package com.jobapplication.Job.Application.service;

import com.jobapplication.Job.Application.dto.NotificationDto;
import com.jobapplication.Job.Application.entity.Notification;
import com.jobapplication.Job.Application.entity.NotificationStatus;
import com.jobapplication.Job.Application.repository.NotificationRepository;
import org.aspectj.weaver.ast.Not;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class NotificationServiceImpl implements NotificationService {

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private NotificationRepository notificationRepository;
    @Override
    public NotificationDto sendNotification(NotificationDto notificationDto) {
        Notification notification = new Notification();
        notification.setUserId(notificationDto.getUserId());
        notification.setStatus(NotificationStatus.UNREAD);
        notification.setAction(notificationDto.getAction());
        notification.setRoute(notificationDto.getRoute());
        notification.setMessage(notificationDto.getMessage());
        notification.setCreatedAt(LocalDateTime.now());
        Notification created = notificationRepository.save(notification);
        return modelMapper.map(created,NotificationDto.class);
    }

    @Override
    public List<NotificationDto> getUnreadNotifications(Long userId) {
        List<Notification> notifications = notificationRepository.findByIdAndStatus(userId,NotificationStatus.UNREAD);
        List<NotificationDto> unreadnot = notifications.stream().map((n)-> modelMapper.map(n,NotificationDto.class)).collect(Collectors.toList());
        return unreadnot;

    }

    @Override
    public String readNotification(Long id) throws Exception {
        Notification notification = notificationRepository.findById(id).orElseThrow(()-> new Exception("Notification not Found!"));
        notification.setStatus(NotificationStatus.READ);
        notificationRepository.save(notification);
        return "Success";
    }
}
