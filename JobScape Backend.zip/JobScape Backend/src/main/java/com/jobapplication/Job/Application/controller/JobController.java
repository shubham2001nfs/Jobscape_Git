package com.jobapplication.Job.Application.controller;

import com.jobapplication.Job.Application.dto.ApplicantDto;
import com.jobapplication.Job.Application.dto.Application;
import com.jobapplication.Job.Application.dto.JobDto;
import com.jobapplication.Job.Application.service.JobService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin
@RequestMapping("/jobs")
@Validated
public class JobController {

    @Autowired
    private JobService jobService;

    @PostMapping("/post")
    public ResponseEntity<JobDto> createJob(@RequestBody JobDto jobDto)
    {
        return new ResponseEntity<>(jobService.postJob(jobDto), HttpStatus.CREATED);
    }

    @GetMapping("/allJobs")
    public ResponseEntity<List<JobDto>> findAllJobs()
    {
        return new ResponseEntity<>(jobService.getAllJobs(), HttpStatus.OK);
    }

    @GetMapping("/get/{id}")
    public ResponseEntity<JobDto> findJob(@PathVariable Long id) throws Exception {
        return new ResponseEntity<>(jobService.getJob(id), HttpStatus.OK);
    }

    @PostMapping("/apply/{id}")
    public ResponseEntity<String> createJob(@PathVariable Long id , @RequestBody ApplicantDto applicantDto) throws Exception {
        return new ResponseEntity<>(jobService.applyJob(id,applicantDto), HttpStatus.OK);
    }

    @GetMapping("/postedJob/{id}")
    public ResponseEntity<List<JobDto>> getPostedJob(@PathVariable Long id) throws Exception {
        return new ResponseEntity<>(jobService.getPostedJob(id), HttpStatus.OK);
    }
    @PostMapping("/changeAppStatus")
    public ResponseEntity<String> changeAppStatus(@RequestBody Application application) throws Exception {
        return new ResponseEntity<>(jobService.changeAppStatus(application), HttpStatus.OK);
    }

    @PutMapping("/closeJob/{id}")
    public ResponseEntity<JobDto> closeJob(@PathVariable Long id) throws Exception {
        return new ResponseEntity<>(jobService.closeJob(id),HttpStatus.OK);
    }

    @PutMapping("/reopenJob/{id}")
    public ResponseEntity<JobDto> reopenJob(@PathVariable Long id) throws Exception {
        return new ResponseEntity<>(jobService.reopenJob(id),HttpStatus.OK);
    }
}
