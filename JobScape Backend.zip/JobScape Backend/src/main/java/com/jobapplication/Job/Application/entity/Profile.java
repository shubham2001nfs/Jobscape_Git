package com.jobapplication.Job.Application.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "profiles")
public class Profile {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String email;
    private String jobTitle;

    @Column(name = "workingCompany")
    private String company;

    @Column(name = "workingLocation")
    private String location;

    @Column(length = 2000)
    private String about;


    @Lob
    @Column
    private String picture;

    private Long totalExp;

    @ElementCollection
    @CollectionTable(name = "profile_skills", joinColumns = @JoinColumn(name = "profile_id"))
    private List<String> skills;

    @ElementCollection
    @CollectionTable(name = "profile_experiences", joinColumns = @JoinColumn(name = "profile_id"))
    private List<Experience> experiences;

    @ElementCollection
    @CollectionTable(name = "profile_certificates", joinColumns = @JoinColumn(name = "profile_id"))
    private List<Certificate> certificates;

    @ElementCollection
    @CollectionTable(name = "profile_saved_jobs", joinColumns = @JoinColumn(name = "profile_id"))
    private List<Long> savedJobs;
}