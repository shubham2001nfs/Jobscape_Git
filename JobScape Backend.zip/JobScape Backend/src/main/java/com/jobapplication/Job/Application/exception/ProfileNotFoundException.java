package com.jobapplication.Job.Application.exception;

public class ProfileNotFoundException extends Exception{

    public ProfileNotFoundException(String message)
    {
        super(message);
    }
}
