package com.jobapplication.Job.Application.entity;

public enum NotificationStatus {
    READ,UNREAD
}
